public class Vehicle {

    private double tankSize;
    private double efficiency;
    private double fuelInTank;

    public double getTankSize() {
        return tankSize;
    }

    public double getEfficiency() {
        return efficiency;
    }

    public double getFuelInTank() {
        return fuelInTank;
    }

    public void setTankSize(double tankSize) {
        this.tankSize = tankSize;
    }

    public void setEfficiency(double efficiency) {
        this.efficiency = efficiency;
    }

    public void setFuelInTank(double fuelInTank) {
        this.fuelInTank = fuelInTank;
    }

    public double availableTankCapacity(double tankSize, double fuelInTank){
        return (tankSize - fuelInTank);
    }

    public void addPetrol(double gallons){
        setFuelInTank(gallons + getFuelInTank());
        System.out.println("Adding " + gallons + " gallons fuel to the tank.");
    }

    public double driveTo(double fuelInTank, double efficiency){
        return (fuelInTank * efficiency);
    }
}
