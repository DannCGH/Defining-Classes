import java.util.Scanner;

public class VehicleDemo {
    public static void main(String[] args){
        Vehicle car = new Vehicle();

        Scanner tankSizeInput = new Scanner(System.in);
        System.out.println("Enter tank size of your car:");
        if (tankSizeInput.hasNextDouble()) {
            car.setTankSize(tankSizeInput.nextDouble());
        } else {
            System.out.println("Invalid tank size. Aborting...");
            System.exit(0);
        }

        Scanner efficiencyInput = new Scanner(System.in);
        System.out.println("Enter the efficiency of the car:");
        if (efficiencyInput.hasNextDouble()) {
            car.setEfficiency(efficiencyInput.nextDouble());
        } else {
            System.out.println("Invalid efficiency. Aborting...");
            System.exit(0);
        }

        System.out.println("Fuel In Tank = " + car.getFuelInTank());
        System.out.println("Total Capacity of Tank = " + car.getTankSize());
        System.out.println("Fuel Efficiency = " + car.getEfficiency());
        System.out.println("Available Capacity of Tank = " + car.availableTankCapacity(car.getTankSize(), car.getFuelInTank()));


        Scanner petrolInput = new Scanner(System.in);
        System.out.println("How many gallons of Petrol to add:");
        if (petrolInput.hasNextDouble()) {
            double petrolInputNumber = petrolInput.nextDouble();
            if (petrolInputNumber <= car.availableTankCapacity(car.getTankSize(), car.getFuelInTank())) {
                car.addPetrol(petrolInputNumber);
            } else {
                System.out.println("Invalid amount of petrol. Aborting...");
                System.exit(0);
            }
        } else {
            System.out.println("Invalid amount of petrol. Aborting...");
            System.exit(0);
        }

        System.out.println("Fuel In Tank = " + car.getFuelInTank() + " gallons");
        System.out.println("You can travel " + car.driveTo(car.getFuelInTank(), car.getEfficiency()) + " miles with available fuel.");
    }
}
